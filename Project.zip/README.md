# Better America
Policy by the people for the people - CU Hack IV Project

## Screenshots
